
var img;
var img2;
var quote = "Journey through the unknown.";

function preload() {

	img = loadImage("drift_edit.jpg");
	img2 = loadImage("drift_text.png");

}

function setup () {

	createCanvas(480, 480);

	textFont("Cinzel");

	fill(0);

	stroke(255);

}

function draw () {

	background(102);

	image(img, 0, 0);

	image(img2, 10, 10, 98.66, 254);

	textSize(24);

	text(quote, 90, 450, 400, 400);
}